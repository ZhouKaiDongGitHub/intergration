CREATE PROCEDURE eis_idx_drop
			AS       
			BEGIN
				/*
				*	drop indexes
				*/
				DECLARE @tsql nvarchar(max)
				DECLARE @dropIDXCount int
				SET @dropIDXCount = 0
				
				DECLARE
					@dropIDXConstraint$index_name varchar(128),
					@dropIDXConstraint$table_schema varchar(128),
					@dropIDXConstraint$table_name varchar(128)
				
				DECLARE dropIDXCursor CURSOR LOCAL FOR
					select distinct index_name, table_schema, table_name
					from TEMP_IDX_COPY_TABLE
				
				OPEN dropIDXCursor
				
				FETCH NEXT FROM dropIDXCursor INTO @dropIDXConstraint$index_name, @dropIDXConstraint$table_schema, @dropIDXConstraint$table_name
				WHILE @@FETCH_STATUS = 0
					BEGIN
						if not exists (select name from sys.indexes where name=@dropIDXConstraint$index_name)
							begin
								FETCH NEXT FROM dropIDXCursor INTO @dropIDXConstraint$index_name, @dropIDXConstraint$table_schema, @dropIDXConstraint$table_name
								CONTINUE
							end
						SET @tsql = 'DROP INDEX [' + @dropIDXConstraint$index_name + '] ON [' + @dropIDXConstraint$table_schema + '].[' + @dropIDXConstraint$table_name + ']'
						EXEC(@tsql)
						SET @dropIDXCount = @dropIDXCount + 1
						FETCH NEXT FROM dropIDXCursor INTO @dropIDXConstraint$index_name, @dropIDXConstraint$table_schema, @dropIDXConstraint$table_name
					END
				CLOSE dropIDXCursor
				DEALLOCATE dropIDXCursor
				
				print 'Indexes dropped: ' + cast(@dropIDXCount as varchar(10))
			END
go

