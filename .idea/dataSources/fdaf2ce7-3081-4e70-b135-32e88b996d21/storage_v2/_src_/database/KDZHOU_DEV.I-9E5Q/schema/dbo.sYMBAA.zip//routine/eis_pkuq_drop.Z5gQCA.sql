CREATE PROCEDURE eis_pkuq_drop
			AS       
			BEGIN
				/*
				* Drop constraints which are PK or UQ
				*/
				DECLARE @tsql nvarchar(max)
				DECLARE @dropPKUQCount int
				SET @dropPKUQCount = 0
				
				DECLARE
					@dropConstraint$constraint_name varchar(128),
					@dropConstraint$table_schema varchar(128),
					@dropConstraint$table_name varchar(128)
				
				DECLARE dropCursor CURSOR LOCAL FOR
					select distinct constraint_name, table_schema, table_name 
					from TEMP_CONSTRAINTS_COPY_TABLE
				
				OPEN dropCursor
				
				FETCH NEXT FROM dropCursor INTO @dropConstraint$constraint_name, @dropConstraint$table_schema, @dropConstraint$table_name
				WHILE @@FETCH_STATUS = 0
					BEGIN
						if not exists (select name from sys.objects where name=@dropConstraint$constraint_name)
							begin
								FETCH NEXT FROM dropCursor INTO @dropConstraint$constraint_name, @dropConstraint$table_schema, @dropConstraint$table_name
								CONTINUE
							end
						SET @tsql = 'ALTER TABLE [' + @dropConstraint$table_schema + '].[' + @dropConstraint$table_name + '] DROP CONSTRAINT [' + @dropConstraint$constraint_name + ']'
						EXEC(@tsql)
						SET @dropPKUQCount = @dropPKUQCount + 1
						FETCH NEXT FROM dropCursor INTO @dropConstraint$constraint_name, @dropConstraint$table_schema, @dropConstraint$table_name
					END
				CLOSE dropCursor
				DEALLOCATE dropCursor
				
				print 'PK UQ dropped: ' + cast(@dropPKUQCount as varchar(10))
			END
go

