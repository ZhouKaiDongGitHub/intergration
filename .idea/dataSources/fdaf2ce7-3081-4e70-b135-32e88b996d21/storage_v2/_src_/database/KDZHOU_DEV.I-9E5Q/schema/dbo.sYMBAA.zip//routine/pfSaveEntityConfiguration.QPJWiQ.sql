CREATE PROCEDURE pfSaveEntityConfiguration(
				@id NUMERIC(19,0),
				@entityCd NVARCHAR(32), 
				@entityVersion NUMERIC(10), 
				@entityType NVARCHAR(32), 
				@entitySubtype NVARCHAR(32), 
				@entityName NVARCHAR(255), 
				@entryPointInd NUMERIC(1,0), 
				@data NVARCHAR(MAX))
			AS
			BEGIN
				IF @id IS NOT NULL AND EXISTS(SELECT blobEC.entityCd FROM  BlobEntityConfiguration blobEC WHERE blobEC.id = @id) 
					UPDATE  BlobEntityConfiguration SET entityCd = @entityCd, entityVersion = @entityVersion, entityType = @entityType, entitySubtype = @entitySubtype, entityName = @entityName, entryPointInd = @entryPointInd, data = @data
					WHERE id = @id;
				ELSE
					INSERT INTO BlobEntityConfiguration (entityCd, entityVersion, entityType, entitySubtype, entityName, entryPointInd, data) 
					values (@entityCd,@entityVersion,@entityType,@entitySubtype,@entityName,@entryPointInd,@data);
			END;
go

