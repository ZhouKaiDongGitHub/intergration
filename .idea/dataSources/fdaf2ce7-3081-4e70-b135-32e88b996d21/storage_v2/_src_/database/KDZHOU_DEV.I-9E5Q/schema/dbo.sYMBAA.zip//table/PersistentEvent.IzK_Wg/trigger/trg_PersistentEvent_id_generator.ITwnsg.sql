CREATE TRIGGER trg_PersistentEvent_id_generator ON PersistentEvent INSTEAD OF INSERT AS IF EXISTS (SELECT RECORD_ID FROM INSERTED WHERE RECORD_ID IS NULL) BEGIN DECLARE @id numeric(19, 0) EXEC ALLOCATENEXTID @ID = @id OUTPUT INSERT INTO PersistentEvent (RECORD_ID) select @id as RECORD_ID from inserted END ELSE INSERT INTO PersistentEvent (RECORD_ID) select RECORD_ID from inserted
go

