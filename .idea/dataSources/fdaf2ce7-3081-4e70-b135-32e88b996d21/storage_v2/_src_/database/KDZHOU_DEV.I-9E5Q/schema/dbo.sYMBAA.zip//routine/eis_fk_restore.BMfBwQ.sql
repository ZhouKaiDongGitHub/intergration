CREATE PROCEDURE eis_fk_restore
		AS       
		BEGIN
			
			DECLARE @tsql nvarchar(max)
			/*
			*	Restore FK
			*/

			DECLARE @restoreFKCount int
			SET @restoreFKCount = 0
			
			DECLARE
				@restoreFKConstraint$constraint_name nvarchar(128),
				@restoreFKConstraint$table_schema nvarchar(128),
				@restoreFKConstraint$table_name nvarchar(128),
				@restoreFKConstraint$ref_table_name nvarchar(128),
				@restoreFKConstraint$delete_action nvarchar(128)
						
			DECLARE restoreFKCursor CURSOR LOCAL FOR  
				SELECT DISTINCT FK_CONSTRAINT_NAME, FK_CONSTRAINT_SCHEMA, FK_TABLE_NAME, UQ_TABLE_NAME, FK_DELETE_RULE FROM TEMP_FK_COPY_TABLE
			
			OPEN restoreFKCursor 
			
			FETCH NEXT FROM restoreFKCursor 
				INTO @restoreFKConstraint$constraint_name, @restoreFKConstraint$table_schema, @restoreFKConstraint$table_name, @restoreFKConstraint$ref_table_name, @restoreFKConstraint$delete_action
			WHILE @@FETCH_STATUS = 0
				BEGIN
					if exists (select name from sys.objects where name=@restoreFKConstraint$constraint_name)
						begin
							FETCH NEXT FROM restoreFKCursor 
				INTO @restoreFKConstraint$constraint_name, @restoreFKConstraint$table_schema, @restoreFKConstraint$table_name, @restoreFKConstraint$ref_table_name, @restoreFKConstraint$delete_action
							CONTINUE
						end
					/*
					* fill columns
					*/
					
					DECLARE @parent_columns nvarchar(1024)
					set @parent_columns = ''
					DECLARE	@parent_column nvarchar(128)
					
					DECLARE columnsFKCursor CURSOR LOCAL FOR  
						select distinct FK_COLUMN_NAME from TEMP_FK_COPY_TABLE where FK_CONSTRAINT_NAME=@restoreFKConstraint$constraint_name
			
					OPEN columnsFKCursor 
					FETCH NEXT FROM columnsFKCursor INTO @parent_column
					WHILE @@FETCH_STATUS = 0
						BEGIN
							SET @parent_columns = @parent_columns + @parent_column + ', '
							FETCH NEXT FROM columnsFKCursor INTO @parent_column
						END
					CLOSE columnsFKCursor 
					DEALLOCATE columnsFKCursor 
					
					SET @parent_columns = left(@parent_columns, len(@parent_columns) - 1)
					/*
					* fill ref_columns
					*/
					
					DECLARE @ref_columns nvarchar(1024)
					set @ref_columns = ''
					DECLARE	@ref_column nvarchar(128)
					
					DECLARE columnsFKCursor CURSOR LOCAL FOR  
						select distinct UQ_COLUMN_NAME from TEMP_FK_COPY_TABLE where FK_CONSTRAINT_NAME=@restoreFKConstraint$constraint_name
			
					OPEN columnsFKCursor 
					FETCH NEXT FROM columnsFKCursor INTO @ref_column
					WHILE @@FETCH_STATUS = 0
						BEGIN
							SET @ref_columns = @ref_columns + @ref_column + ', '
							FETCH NEXT FROM columnsFKCursor INTO @ref_column
						END
					CLOSE columnsFKCursor 
					DEALLOCATE columnsFKCursor 
					
					SET @ref_columns = left(@ref_columns, len(@ref_columns) - 1)
					
					SET @tsql = 'ALTER TABLE [' + @restoreFKConstraint$table_schema + '].[' + @restoreFKConstraint$table_name + '] WITH NOCHECK ADD CONSTRAINT ' + @restoreFKConstraint$constraint_name + ' FOREIGN KEY (' + @parent_columns + ') REFERENCES [' + @restoreFKConstraint$table_schema + '].[' + @restoreFKConstraint$ref_table_name + '] (' + @ref_columns + ') ON DELETE ' + @restoreFKConstraint$delete_action
					EXEC(@tsql)
					SET @restoreFKCount = @restoreFKCount + 1
										
					FETCH NEXT FROM restoreFKCursor
						INTO @restoreFKConstraint$constraint_name, @restoreFKConstraint$table_schema, @restoreFKConstraint$table_name, @restoreFKConstraint$ref_table_name, @restoreFKConstraint$delete_action
				END
			CLOSE restoreFKCursor
			DEALLOCATE restoreFKCursor
			
			print 'FK restored: ' + cast(@restoreFKCount as varchar(10))
		END
go

