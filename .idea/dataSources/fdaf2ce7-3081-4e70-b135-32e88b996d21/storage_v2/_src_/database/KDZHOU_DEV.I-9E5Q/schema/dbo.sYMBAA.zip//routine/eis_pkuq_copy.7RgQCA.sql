CREATE PROCEDURE eis_pkuq_copy  
			AS       
			BEGIN
				IF EXISTS  (SELECT * FROM sysobjects WHERE id = OBJECT_ID('TEMP_CONSTRAINTS_COPY_TABLE'))
				DROP TABLE TEMP_CONSTRAINTS_COPY_TABLE
				/*
				* Copy primary key and unique constraint info to TEMP_CONSTRAINTS_COPY_TABLE
				*/
				
				select u.constraint_name, u.table_schema, u.table_name, u.column_name, c.type into TEMP_CONSTRAINTS_COPY_TABLE
				from INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE u
				join sys.key_constraints c on u.constraint_name=c.name
				order by u.constraint_name
			END
go

