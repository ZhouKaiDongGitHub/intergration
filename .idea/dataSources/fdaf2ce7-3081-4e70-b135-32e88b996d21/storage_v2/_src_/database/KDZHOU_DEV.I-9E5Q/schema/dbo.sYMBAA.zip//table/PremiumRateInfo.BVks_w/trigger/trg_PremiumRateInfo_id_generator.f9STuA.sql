CREATE TRIGGER trg_PremiumRateInfo_id_generator ON PremiumRateInfo INSTEAD OF INSERT AS IF EXISTS (SELECT id FROM INSERTED WHERE id IS NULL) BEGIN DECLARE @id numeric(19, 0) EXEC ALLOCATENEXTID @ID = @id OUTPUT INSERT INTO PremiumRateInfo (id) select @id as id from inserted END ELSE INSERT INTO PremiumRateInfo (id) select id from inserted
go

