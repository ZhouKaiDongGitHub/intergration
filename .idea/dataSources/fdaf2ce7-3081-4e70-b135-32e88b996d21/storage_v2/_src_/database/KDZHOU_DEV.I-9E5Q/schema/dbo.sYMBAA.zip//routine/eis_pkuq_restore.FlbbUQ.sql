CREATE PROCEDURE eis_pkuq_restore
			AS       
			BEGIN
				
				DECLARE @tsql nvarchar(max)
				/*
				*	Restore PK and UQ constraints
				*/
		
				DECLARE @restorePKUQCount int
				SET @restorePKUQCount = 0
				DECLARE
					@restoreConstraint$constraint_name nvarchar(128),
					@restoreConstraint$table_schema nvarchar(128),
					@restoreConstraint$table_name nvarchar(128),
					@restoreConstraint$type char(2) 
							
				DECLARE restoreCursor CURSOR LOCAL FOR  
					SELECT DISTINCT constraint_name, table_schema, table_name, type FROM TEMP_CONSTRAINTS_COPY_TABLE
				OPEN restoreCursor 
				
				FETCH NEXT FROM restoreCursor 
					INTO @restoreConstraint$constraint_name, @restoreConstraint$table_schema, @restoreConstraint$table_name, @restoreConstraint$type
				WHILE @@FETCH_STATUS = 0
					BEGIN
						if exists (select name from sys.objects where name=@restoreConstraint$constraint_name)
							begin
								FETCH NEXT FROM restoreCursor 
					INTO @restoreConstraint$constraint_name, @restoreConstraint$table_schema, @restoreConstraint$table_name, @restoreConstraint$type
								CONTINUE
							end
						DECLARE @columns nvarchar(1024)
						set @columns = ''
						DECLARE	@column nvarchar(128)
						
						DECLARE columnsCursor CURSOR LOCAL FOR  
							select distinct column_name from TEMP_CONSTRAINTS_COPY_TABLE where constraint_name=@restoreConstraint$constraint_name
				
						OPEN columnsCursor 
						FETCH NEXT FROM columnsCursor INTO @column
						WHILE @@FETCH_STATUS = 0
							BEGIN
								SET @columns = @columns + @column + ', '
								FETCH NEXT FROM columnsCursor INTO @column
							END
						CLOSE columnsCursor 
						DEALLOCATE columnsCursor 
						
						SET @columns = left(@columns, len(@columns) - 1)
						if @restoreConstraint$type = 'PK'
							begin
								SET @tsql = 'ALTER TABLE [' + @restoreConstraint$table_schema + '].[' + @restoreConstraint$table_name + '] WITH NOCHECK ADD CONSTRAINT ' + @restoreConstraint$constraint_name + ' PRIMARY KEY CLUSTERED (' + @columns + ')'
								EXEC(@tsql)
								SET @restorePKUQCount = @restorePKUQCount + 1
							end
						
						if @restoreConstraint$type = 'UQ'
							begin
								SET @tsql = 'ALTER TABLE [' + @restoreConstraint$table_schema + '].[' + @restoreConstraint$table_name + '] WITH NOCHECK ADD CONSTRAINT ' + @restoreConstraint$constraint_name + ' UNIQUE (' + @columns + ')'
								EXEC(@tsql)
								SET @restorePKUQCount = @restorePKUQCount + 1
							end
						
						FETCH NEXT FROM restoreCursor
							INTO @restoreConstraint$constraint_name, @restoreConstraint$table_schema, @restoreConstraint$table_name, @restoreConstraint$type
					END
				CLOSE restoreCursor
				DEALLOCATE restoreCursor
				
				print 'PK UQ restored: ' + cast(@restorePKUQCount as varchar(10))
			END
go

