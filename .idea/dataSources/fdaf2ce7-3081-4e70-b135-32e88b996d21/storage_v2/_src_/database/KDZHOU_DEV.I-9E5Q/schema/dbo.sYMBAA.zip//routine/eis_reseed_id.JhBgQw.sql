CREATE PROCEDURE eis_reseed_id(@ID numeric(19, 0)) AS
				DECLARE @val numeric(19, 0) = (@ID / 1000)
				DELETE FROM eis_sequence
				DBCC CHECKIDENT (eis_sequence, reseed, @val)
				SET @val = @ID % 1000
				DELETE FROM id_sequence
				DBCC CHECKIDENT (id_sequence, reseed, @val)
			RETURN
go

