CREATE PROCEDURE eis_create_id_trigger (@table sysname, @column sysname) AS 	-- identity generation procedure
			BEGIN
				IF EXISTS (SELECT c.name FROM sys.columns c WHERE c.name != @column AND c.object_id = object_id(@table))	-- check whether other than identity columns exists
					BEGIN
						DECLARE @sqlColumns nvarchar(max)
						SET @sqlColumns = dbo.eis_columns_to_string(@table, @column)
						EXEC('CREATE TRIGGER trg_' + @table + '_id_generator ON '+ @table + ' INSTEAD OF INSERT AS ' + 
							'IF EXISTS (SELECT ' + @column + ' FROM INSERTED WHERE ' + @column + ' IS NULL) ' +	-- check if inserted id is null
								'BEGIN ' + 	-- continue insert with generated id
									'DECLARE @id numeric(19, 0) ' +
									'EXEC ALLOCATENEXTID @ID = @id OUTPUT ' +
									'DECLARE @inserted_count numeric(19, 0) ' +
									'select @inserted_count = COUNT(*) from inserted ' +
									'IF @inserted_count = 1 ' +
										'INSERT INTO ' + @table + ' (' + @column + ',' + @sqlColumns +') select @id as ' + @column + ',' + @sqlColumns + ' from inserted ' + 
									'ELSE ' +
										'BEGIN ' + 
											'DECLARE @val numeric(19, 0) ' +
											'INSERT INTO ' + @table + ' (' + @column + ',' + @sqlColumns +') select ((ROW_NUMBER() over (order by @val)) + @id - 1) as ' + @column + ',' + @sqlColumns + ' from inserted ' + 
											'SET @val = (@id + @inserted_count - 1) ' +
											'EXEC eis_reseed_id @ID = @val ' +
										'END ' +
								'END ' +
							'ELSE ' + 	-- no action, continue insert
								'INSERT INTO ' + @table + ' (' + @column + ',' + @sqlColumns +') select ' + @column + ',' + @sqlColumns + ' from inserted')
					END
				ELSE
					EXEC('CREATE TRIGGER trg_' + @table + '_id_generator ON '+ @table + ' INSTEAD OF INSERT AS ' + 
							'IF EXISTS (SELECT ' + @column + ' FROM INSERTED WHERE ' + @column + ' IS NULL) ' +	-- check if inserted id is null
								'BEGIN ' + 	-- continue insert with generated id
									'DECLARE @id numeric(19, 0) ' +
									'EXEC ALLOCATENEXTID @ID = @id OUTPUT ' +
									'INSERT INTO ' + @table + ' (' + @column + ') select @id as ' + @column + ' from inserted ' + 
								'END ' +
							'ELSE ' + 	-- no action, continue insert
								'INSERT INTO ' + @table + ' (' + @column + ') select ' + @column + ' from inserted')
			END
go

