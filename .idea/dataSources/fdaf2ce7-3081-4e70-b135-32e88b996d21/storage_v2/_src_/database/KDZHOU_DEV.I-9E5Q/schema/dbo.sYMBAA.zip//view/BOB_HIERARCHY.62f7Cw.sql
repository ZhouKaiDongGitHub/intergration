CREATE VIEW BOB_HIERARCHY AS
			SELECT B.code AS CODE,
			  F.code  AS PARENT_CODE,
			  B.DTYPE AS THIRDPARTY_DTYPE,
			  B.channelCd AS CHANNEL
			FROM ThirdParty B
			LEFT OUTER JOIN ThirdPartyRelationship E
			ON (E.relatedTo_id = B.id )
			LEFT OUTER JOIN ThirdParty F
			ON ( F.id = E.sourceParty_id )
go

