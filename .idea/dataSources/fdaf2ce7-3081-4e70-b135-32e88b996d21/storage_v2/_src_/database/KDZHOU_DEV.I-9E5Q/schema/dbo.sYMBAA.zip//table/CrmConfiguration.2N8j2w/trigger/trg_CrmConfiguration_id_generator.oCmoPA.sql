CREATE TRIGGER trg_CrmConfiguration_id_generator ON CrmConfiguration INSTEAD OF INSERT AS IF EXISTS (SELECT id FROM INSERTED WHERE id IS NULL) BEGIN DECLARE @id numeric(19, 0) EXEC ALLOCATENEXTID @ID = @id OUTPUT INSERT INTO CrmConfiguration (id) select @id as id from inserted END ELSE INSERT INTO CrmConfiguration (id) select id from inserted
go

