CREATE PROCEDURE eis_drop_column (@tablename NVARCHAR(max), @columnname NVARCHAR(max))
			AS
			BEGIN

		      -- SET NOCOUNT ON added to prevent extra result sets from
		      -- interfering with SELECT statements.
		      SET NOCOUNT ON;
		      DECLARE @ConstraintName NVARCHAR(200);
		      DECLARE @sql NVARCHAR(max);
		
		      --Remove Constraint
		      DECLARE constraintCursor CURSOR
		      FOR
		      SELECT CONSTRAINT_NAME
		      FROM INFORMATION_SCHEMA.CONSTRAINT_COLUMN_USAGE WHERE TABLE_NAME = @tablename AND COLUMN_NAME = @columnname;
		
		      OPEN constraintCursor;
		
		      FETCH NEXT FROM constraintCursor
		      INTO @ConstraintName
		      WHILE @@FETCH_STATUS = 0
		      BEGIN
		            SET @sql = 'ALTER TABLE ' + @tablename + ' DROP CONSTRAINT ' + @ConstraintName
		            PRINT @sql
		            EXEC sp_executesql @sql
		      
		            FETCH NEXT FROM constraintCursor 
		            INTO @ConstraintName
		      END
		      CLOSE constraintCursor;
		      DEALLOCATE constraintCursor;
		                  
		      --Remove Default Constraint
		      DECLARE defaultConstraintCursor CURSOR
		      FOR
		      SELECT d.name
		      FROM sys.default_constraints d
		      join sys.columns c ON c.column_id = d.parent_column_id AND c.object_id = d.parent_object_id
		      join sys.objects o ON o.object_id = d.parent_object_id
		      WHERE o.name = @tablename AND c.name = @columnname;
		      
		      OPEN defaultConstraintCursor;
		
		      FETCH NEXT FROM defaultConstraintCursor
		      INTO @ConstraintName
		      WHILE @@FETCH_STATUS = 0
		      BEGIN
		            SET @sql = 'ALTER TABLE ' + @tablename + ' DROP CONSTRAINT ' + @ConstraintName
		            PRINT @sql
		            EXEC sp_executesql @sql
		      
		            FETCH NEXT FROM defaultConstraintCursor 
		            INTO @ConstraintName
		      END
		      CLOSE defaultConstraintCursor;
		      DEALLOCATE defaultConstraintCursor;
		
		      --Remove Index
		      DECLARE indexCursor CURSOR
		      FOR
		      SELECT i.name
		      FROM sys.indexes i
		      JOIN sys.index_columns ic ON ic.index_id = i.index_id and ic.object_id=i.object_id
		      JOIN sys.columns c ON c.column_id = ic.column_id and c.object_id=i.object_id
		      JOIN sys.objects o ON o.object_id = i.object_id
		      where o.name = @tablename AND i.type=2 AND c.name = @columnname AND is_unique_constraint = 0;
		      
		      OPEN indexCursor;
		
		      FETCH NEXT FROM indexCursor
		      INTO @ConstraintName
		      WHILE @@FETCH_STATUS = 0
		      BEGIN
		            SET @sql = 'DROP INDEX ' + @ConstraintName + ' ON ' + @tablename
		            PRINT @sql
		            EXEC sp_executesql @sql
		      
		            FETCH NEXT FROM indexCursor 
		            INTO @ConstraintName
		      END
		      CLOSE indexCursor;
		      DEALLOCATE indexCursor;
		
		      --Remove Stats
		      DECLARE statsCursor CURSOR
		      FOR
		      SELECT s.name
		      FROM sys.stats AS s
		      INNER JOIN sys.stats_columns AS sc 
		            ON s.object_id = sc.object_id AND s.stats_id = sc.stats_id
		      INNER JOIN sys.columns AS c 
		            ON sc.object_id = c.object_id AND c.column_id = sc.column_id
		      WHERE s.object_id = OBJECT_ID(@tablename)
		      AND c.name = @columnname;
		      
		      OPEN statsCursor;
		
		      FETCH NEXT FROM statsCursor
		      INTO @ConstraintName
		      WHILE @@FETCH_STATUS = 0
		      BEGIN
		            SET @sql = 'DROP STATISTICS ' + @tablename + '.' + @ConstraintName
		            PRINT @sql
		            EXEC sp_executesql @sql
		      
		            FETCH NEXT FROM statsCursor 
		            INTO @ConstraintName
		      END
		      CLOSE statsCursor;
		      DEALLOCATE statsCursor;
		      
		      IF EXISTS(SELECT * FROM sys.columns WHERE name = @columnname AND object_id = Object_ID(@tablename))
		      BEGIN
		            SET @sql = 'ALTER TABLE ' + @tablename + ' DROP COLUMN ' + @columnname
		            print @sql
		            EXEC sp_executesql @sql
		      END
		      ELSE PRINT ('Warning: Column: ' + @columnname + ' not found on table: ' + @tablename);
			END
go

