CREATE FUNCTION dbo.eis_columns_to_string (@table sysname, @exclude sysname) RETURNS nvarchar(max) -- creates comma separated non-computed column list string representation (excluding id column)
			AS BEGIN
				DECLARE @result nvarchar(max)
				SET @result = ''
				SELECT @result = @result + ',[' + name + ']' FROM sys.columns WHERE object_id = object_id(@table) and name != @exclude and is_computed = 0
				SELECT @result = STUFF(@result, 1, 1, '')
				RETURN @result
			END
go

