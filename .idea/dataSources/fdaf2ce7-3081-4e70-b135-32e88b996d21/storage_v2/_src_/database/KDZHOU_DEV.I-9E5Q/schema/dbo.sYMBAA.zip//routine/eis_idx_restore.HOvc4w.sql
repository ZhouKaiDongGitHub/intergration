CREATE PROCEDURE eis_idx_restore
			AS       
			BEGIN
				DECLARE @tsql nvarchar(max)
				
				/*
				*	restore indexes
				*/
			
				DECLARE @restoreIDXCount int
				SET @restoreIDXCount = 0
				
				DECLARE
					@restoreIDXConstraint$table_name nvarchar(128),
					@restoreIDXConstraint$table_schema nvarchar(128),
					@restoreIDXConstraint$index_name nvarchar(128),
					@restoreIDXConstraint$is_unique bit 
							
				DECLARE restoreIDXCursor CURSOR LOCAL FOR  
					SELECT table_name, table_schema, index_name, is_unique FROM TEMP_IDX_COPY_TABLE
				
				OPEN restoreIDXCursor 
				
				FETCH NEXT FROM restoreIDXCursor 
					INTO @restoreIDXConstraint$table_name, @restoreIDXConstraint$table_schema, @restoreIDXConstraint$index_name, @restoreIDXConstraint$is_unique
				WHILE @@FETCH_STATUS = 0
					BEGIN
						
						if exists (select idx.name from sys.indexes idx inner join sys.objects tb on tb.object_id = idx.object_id where idx.name=@restoreIDXConstraint$index_name)
							begin
								FETCH NEXT FROM restoreIDXCursor 
					INTO @restoreIDXConstraint$table_name, @restoreIDXConstraint$table_schema, @restoreIDXConstraint$index_name, @restoreIDXConstraint$is_unique
								CONTINUE
							end
						
						DECLARE @idx_columns nvarchar(1024)
						set @idx_columns = ''
						DECLARE	@idx_column nvarchar(128)
						
						DECLARE columnsIDXCursor CURSOR LOCAL FOR  
							select column_name from TEMP_IDX_COPY_TABLE
	                              where table_schema=@restoreIDXConstraint$table_schema and table_name=@restoreIDXConstraint$table_name and index_name=@restoreIDXConstraint$index_name
				
						OPEN columnsIDXCursor 
						FETCH NEXT FROM columnsIDXCursor INTO @idx_column
						WHILE @@FETCH_STATUS = 0
							BEGIN
								SET @idx_columns = @idx_columns + @idx_column + ', '
								FETCH NEXT FROM columnsIDXCursor INTO @idx_column
							END
						CLOSE columnsIDXCursor 
						DEALLOCATE columnsIDXCursor 
						
						SET @idx_columns = left(@idx_columns, len(@idx_columns) - 1)
						
						if @restoreIDXConstraint$is_unique = 1
							begin
								SET @tsql = 'CREATE UNIQUE INDEX [' + @restoreIDXConstraint$index_name + '] ON [' + @restoreIDXConstraint$table_schema + '].[' + @restoreIDXConstraint$table_name + '] (' + @idx_columns + ')'
								EXEC(@tsql)
								SET @restoreIDXCount = @restoreIDXCount + 1
							end
						
						if @restoreIDXConstraint$is_unique = 0
							begin
								SET @tsql = 'CREATE INDEX [' + @restoreIDXConstraint$index_name + '] ON [' + @restoreIDXConstraint$table_schema + '].[' + @restoreIDXConstraint$table_name + '] (' + @idx_columns + ')'
								EXEC(@tsql)
								SET @restoreIDXCount = @restoreIDXCount + 1
							end
						
						FETCH NEXT FROM restoreIDXCursor 
							INTO @restoreIDXConstraint$table_name, @restoreIDXConstraint$table_schema, @restoreIDXConstraint$index_name, @restoreIDXConstraint$is_unique
					END
				CLOSE restoreIDXCursor
				DEALLOCATE restoreIDXCursor
				
				print 'Indexes restored: ' + cast(@restoreIDXCount as varchar(10))
			END
go

