CREATE PROCEDURE pfSaveRuntimeBlob(
                @id             NUMERIC(19,0),
                @productCd      VARCHAR(255),
                @productVersion NUMERIC(10),
                @productName    VARCHAR(255),
                @productStatus  VARCHAR(255),
                @rootEntityType VARCHAR(32),
                @effectiveDate  DATETIME,
                @expirationDate DATETIME,
                @LOBCd          VARCHAR(255),
                @broadLOBCd     VARCHAR(255),
                @countryCd      VARCHAR(2),
                @description    VARCHAR(255),
                @data           VARBINARY(MAX)
            )
            AS
                BEGIN
                    IF @id IS NOT NULL AND EXISTS(SELECT blobPD.productCd
                                                  FROM ProductDefinition blobPD
                                                  WHERE blobPD.id = @id)
                        UPDATE ProductDefinition
                        SET
                            productCd      = @productCd,
                            productVersion = @productVersion,
                            productName    = @productName,
                            productStatus  = @productStatus,
                            rootEntityType = @rootEntityType,
                            effectiveDate  = @effectiveDate,
                            expirationDate = @expirationDate,
                            LOBCd          = @LOBCd,
                            broadLOBCd     = @broadLOBCd,
                            countryCd      = @countryCd,
                            description    = @description,
                            data           = @data
                        WHERE id = @id;
                    ELSE
                        INSERT INTO ProductDefinition
                        (
                            productCd,
                            productVersion,
                            productName,
                            productStatus,
                            rootEntityType,
                            effectiveDate,
                            expirationDate,
                            LOBCd,
                            broadLOBCd,
                            countryCd,
                            description,
                            data
                        )
                        VALUES
                        (
                            @productCd,
                            @productVersion,
                            @productName,
                            @productStatus,
                            @rootEntityType,
                            @effectiveDate,
                            @expirationDate,
                            @LOBCd,
                            @broadLOBCd,
                            @countryCd,
                            @description,
                            @data
                        );
                END;
go

