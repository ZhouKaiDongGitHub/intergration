CREATE PROCEDURE eis_fk_drop
			AS       
			BEGIN
				/*
				*	drop foreign keys
				*/
				DECLARE @tsql nvarchar(max)			

				DECLARE @dropFKCount int
				SET @dropFKCount = 0
				
				DECLARE
					@dropFKConstraint$constraint_name varchar(128),
					@dropFKConstraint$table_schema varchar(128),
					@dropFKConstraint$table_name varchar(128)
				
				DECLARE dropFKCursor CURSOR LOCAL FOR
					select distinct FK_CONSTRAINT_NAME, FK_CONSTRAINT_SCHEMA, FK_TABLE_NAME 
					from TEMP_FK_COPY_TABLE 
				
				OPEN dropFKCursor
				
				FETCH NEXT FROM dropFKCursor INTO @dropFKConstraint$constraint_name, @dropFKConstraint$table_schema, @dropFKConstraint$table_name
				WHILE @@FETCH_STATUS = 0
					BEGIN
						if not exists (select name from sys.objects where name=@dropFKConstraint$constraint_name)
							begin
								FETCH NEXT FROM dropFKCursor INTO @dropFKConstraint$constraint_name, @dropFKConstraint$table_schema, @dropFKConstraint$table_name
								CONTINUE
							end
						SET @tsql = 'ALTER TABLE [' + @dropFKConstraint$table_schema + '].[' + @dropFKConstraint$table_name + '] DROP CONSTRAINT [' + @dropFKConstraint$constraint_name + ']'
						EXEC(@tsql)
						SET @dropFKCount = @dropFKCount + 1
						FETCH NEXT FROM dropFKCursor INTO @dropFKConstraint$constraint_name, @dropFKConstraint$table_schema, @dropFKConstraint$table_name
					END
				CLOSE dropFKCursor
				DEALLOCATE dropFKCursor
				
				print 'FK dropped: ' + cast(@dropFKCount as varchar(10))
			END
go

