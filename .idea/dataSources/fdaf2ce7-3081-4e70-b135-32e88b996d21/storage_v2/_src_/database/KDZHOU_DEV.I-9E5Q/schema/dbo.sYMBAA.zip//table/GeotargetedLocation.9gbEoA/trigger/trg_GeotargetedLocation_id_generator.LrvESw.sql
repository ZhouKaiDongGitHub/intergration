CREATE TRIGGER trg_GeotargetedLocation_id_generator ON GeotargetedLocation INSTEAD OF INSERT AS IF EXISTS (SELECT id FROM INSERTED WHERE id IS NULL) BEGIN DECLARE @id numeric(19, 0) EXEC ALLOCATENEXTID @ID = @id OUTPUT INSERT INTO GeotargetedLocation (id) select @id as id from inserted END ELSE INSERT INTO GeotargetedLocation (id) select id from inserted
go

