CREATE TRIGGER trg_ScannedClaimDocEntity_id_generator ON ScannedClaimDocEntity INSTEAD OF INSERT AS IF EXISTS (SELECT id FROM INSERTED WHERE id IS NULL) BEGIN DECLARE @id numeric(19, 0) EXEC ALLOCATENEXTID @ID = @id OUTPUT INSERT INTO ScannedClaimDocEntity (id) select @id as id from inserted END ELSE INSERT INTO ScannedClaimDocEntity (id) select id from inserted
go

