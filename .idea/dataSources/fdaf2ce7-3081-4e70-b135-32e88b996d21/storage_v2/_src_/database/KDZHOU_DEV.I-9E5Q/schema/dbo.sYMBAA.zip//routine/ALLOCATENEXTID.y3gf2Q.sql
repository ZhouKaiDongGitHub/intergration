CREATE PROCEDURE ALLOCATENEXTID (@ID numeric(19, 0) OUTPUT) AS
				DECLARE @id_sequence numeric(19, 0)
				DECLARE @eis_sequence numeric(19, 0)

				INSERT INTO id_sequence VALUES (0) SELECT @id_sequence = @@IDENTITY % 1000
				
				IF @id_sequence = 0
					BEGIN
						INSERT INTO eis_sequence VALUES (0) SELECT @eis_sequence = @@IDENTITY * 1000
					END
				ELSE 
					SET @eis_sequence = IDENT_CURRENT('eis_sequence') * 1000
				
				SET @ID = @id_sequence + @eis_sequence ;
			RETURN
go

