CREATE PROCEDURE dbo.eis_change_clmn_dtype
			AS       
			BEGIN
				
				DECLARE @tsql nvarchar(max)
				/*
				* Change columns data type
				*/
				
				DECLARE @changeColumnCount int
				SET @changeColumnCount = 0
				
				DECLARE
					@changeColumn$table_name varchar(128),
					@changeColumn$table_schema varchar(128),
					@changeColumn$column_name varchar(128),
					@changeColumn$character_maximum_length int,
					@changeColumn$is_nullable varchar(3)
				
				DECLARE changeCursor CURSOR LOCAL FOR  
					SELECT c.table_name, c.table_schema, c.column_name, c.character_maximum_length, c.is_nullable
					FROM INFORMATION_SCHEMA.COLUMNS AS c
					WHERE DATA_TYPE = 'varchar'
		   
				OPEN changeCursor 
				
				FETCH NEXT FROM changeCursor INTO @changeColumn$table_name, @changeColumn$table_schema, @changeColumn$column_name, @changeColumn$character_maximum_length, @changeColumn$is_nullable
				WHILE @@FETCH_STATUS = 0
					BEGIN
						if @changeColumn$is_nullable = 'NO' and @changeColumn$character_maximum_length < 4001
							begin
								SET @tsql = 'ALTER TABLE [' + @changeColumn$table_schema + '].[' + @changeColumn$table_name + '] ALTER COLUMN [' + @changeColumn$column_name + '] nvarchar(' + CAST (@changeColumn$character_maximum_length as varchar(128)) + ') NOT NULL'
								EXEC(@tsql)
								SET @changeColumnCount = @changeColumnCount + 1
							end
						if @changeColumn$is_nullable = 'YES' and @changeColumn$character_maximum_length < 4001
							begin
								SET @tsql = 'ALTER TABLE [' + @changeColumn$table_schema + '].[' + @changeColumn$table_name + '] ALTER COLUMN [' + @changeColumn$column_name + '] nvarchar(' + CAST (@changeColumn$character_maximum_length as varchar(128)) + ') NULL'
								EXEC(@tsql)
								SET @changeColumnCount = @changeColumnCount + 1
							end
						FETCH NEXT FROM changeCursor
							INTO @changeColumn$table_name, @changeColumn$table_schema, @changeColumn$column_name, @changeColumn$character_maximum_length, @changeColumn$is_nullable
					END
				CLOSE changeCursor
				DEALLOCATE changeCursor
				
				print 'Columns altered: ' + cast(@changeColumnCount as varchar(10))
			END
go

