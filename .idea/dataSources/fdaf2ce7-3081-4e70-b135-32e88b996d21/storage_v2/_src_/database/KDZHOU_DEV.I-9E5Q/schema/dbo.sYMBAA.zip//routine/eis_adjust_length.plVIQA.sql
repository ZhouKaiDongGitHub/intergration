CREATE PROCEDURE dbo.eis_adjust_length
		AS       
		BEGIN
			DECLARE @tsql nvarchar(max)
			/*
			* Change columns length
			*/
			
			/*
			*	create length table and insert data
			*/
			create table TEMP_ADJUSTED_CLMN_LENGTH (table_name nvarchar(128) , column_name nvarchar(128), column_length int )

			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'ACTIVITY', N'LOBCd', '20')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'ACTIVITY_HISTORY ', N'LOBCd ', '20')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'AddressEntity', N'DTYPE', '124')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'AddressEntity', N'postDirectionCd', '1020')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'AddressEntity', N'preDirectionCd', '1020')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'AddressEntity', N'suburb', '1020')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'AddressEntity', N'township', '1020')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'AttributeConfiguration', N'label', '300')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'BaseLoss', N'damageDesc', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'BaseLoss', N'injuryAdditionalInfo', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'BaseLoss', N'natureOfInjuryDesc', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'BillablePolicyTerm', N'paymentPlan', '20')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'BusinessRule', N'description ', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'BusinessRule', N'name', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'ClaimsParty', N'involvementDesc', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'ClaimsParty', N'partyEmail', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'ClaimsPartyAssessment', N'damageDesc', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'ClaimsSummaryInfo', N'fraudExplanation', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'ClaimsSummaryInfo', N'lossDesc', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'ConcreteUserComponent', N'componentName', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'ConcreteUserComponent', N'inheritedComponentName', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'CoverageDefinition', N'applicableTo', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'CoverageDefinition', N'coverageCd', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'CoverageDefinition', N'internalCoverageCd', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'DwellRatingInfo', N'reasonForNotOrderingInspection', '50')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'FormDefinition', N'applicableCoverageCd', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'FormDefinition', N'applicableTo', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'FormDefinition', N'DTYPE', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'Installment', N'type', '20')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'InsuredPrincipal', N'occupationDesc', '20')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'InvestigationInfo', N'atFaultExplanation', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'InvestigationInfo', N'investigationActivity', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'License', N'licensePermitNumber', '1020')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'License', N'licenseStatusCd', '1020')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'License', N'licenseTypeCd', '80')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'LicenseApplicability', N'LOBCd', '80')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'LicenseApplicability', N'stateProvCd', '80')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'LookupValue', N'description', '1024')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'MarketingEntity', N'brandCd', '80')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'MarketingEntity', N'campaignCd', '80')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'MarketingEntity', N'channelCd', '80')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'MarketingEntity', N'legalEntityCd', '80')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'MarketingEntity', N'referenceNo', '80')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'MarketingEntity', N'referralCd', '80')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'MarketingEntity', N'subCampaignCd', '80')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'PaymentDetails', N'cardType', '50')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'PolicyAdditionalInfo', N'insuranceExplanation ', '50')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'ProductDefinition', N'billingPeriodTypeCd', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'ProductDefinition', N'LOBCd', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'ProductDefinition', N'productCd', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'ProductDefinition', N'productEngineCd', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'ProductDefinition', N'productName', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'ProductDefinition', N'productStatus', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'ProductDefinition', N'SubLOBCd', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'ProductRelationship', N'relationshipType', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'SequenceTrackingEntry', N'oid', '80')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'SequenceTrackingEntry', N'refNumber', '80')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'Tab', N'tabLabel', '255')
			INSERT INTO TEMP_ADJUSTED_CLMN_LENGTH VALUES (N'VendorProfile', N'licenceNumber', '50')
			
			DECLARE @changeLenColumnCount int
			SET @changeLenColumnCount = 0
			
			DECLARE
				@changeLenColumn$table_name varchar(128),
				@changeLenColumn$table_schema varchar(128),
				@changeLenColumn$column_name varchar(128),
				@changeLenColumn$length int,
				@changeLenColumn$is_nullable varchar(3)
			
			DECLARE changeLenCursor CURSOR LOCAL FOR  
				SELECT ta.table_name, isc.table_schema, ta.column_name, ta.column_length, isc.is_nullable
				FROM TEMP_ADJUSTED_CLMN_LENGTH AS ta
				join INFORMATION_SCHEMA.COLUMNS as isc on ta.column_name=isc.column_name and ta.table_name=isc.table_name
	   
			OPEN changeLenCursor 
			
			FETCH NEXT FROM changeLenCursor INTO @changeLenColumn$table_name, @changeLenColumn$table_schema, @changeLenColumn$column_name, @changeLenColumn$length, @changeLenColumn$is_nullable
			WHILE @@FETCH_STATUS = 0
				BEGIN
					if @changeLenColumn$is_nullable = 'NO'
						begin
							SET @tsql = 'ALTER TABLE [' + @changeLenColumn$table_schema + '].[' + @changeLenColumn$table_name + '] ALTER COLUMN [' + @changeLenColumn$column_name + '] nvarchar(' + CAST (@changeLenColumn$length as varchar(128)) + ') NOT NULL'
							EXEC(@tsql)
							SET @changeLenColumnCount = @changeLenColumnCount + 1
						end
					if @changeLenColumn$is_nullable = 'YES'
						begin
							SET @tsql = 'ALTER TABLE [' + @changeLenColumn$table_schema + '].[' + @changeLenColumn$table_name + '] ALTER COLUMN [' + @changeLenColumn$column_name + '] nvarchar(' + CAST (@changeLenColumn$length as varchar(128)) + ') NULL'
							EXEC(@tsql)
							SET @changeLenColumnCount = @changeLenColumnCount + 1
						end
					FETCH NEXT FROM changeLenCursor
						INTO @changeLenColumn$table_name, @changeLenColumn$table_schema, @changeLenColumn$column_name, @changeLenColumn$length, @changeLenColumn$is_nullable
				END
			CLOSE changeLenCursor
			DEALLOCATE changeLenCursor
			
			print 'Columns length altered: ' + cast(@changeLenColumnCount as varchar(10))
	END
go

