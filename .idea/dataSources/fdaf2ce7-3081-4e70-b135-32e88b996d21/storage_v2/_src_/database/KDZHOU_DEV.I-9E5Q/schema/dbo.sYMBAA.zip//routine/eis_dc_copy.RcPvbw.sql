CREATE PROCEDURE dbo.eis_dc_copy
			AS       
			BEGIN
				IF EXISTS  (SELECT * FROM dbo.sysobjects WHERE id = OBJECT_ID('[dbo].[TEMP_DC_COPY_TABLE]'))
				DROP TABLE [dbo].[TEMP_DC_COPY_TABLE]
				/*
				*	copy default constraints to TEMP_DC_COPY_TABLE
				*/
				select isc.table_schema, isc.table_name, dc.name, dc.definition, isc.column_name
				into TEMP_DC_COPY_TABLE
				from sys.default_constraints dc
				join INFORMATION_SCHEMA.COLUMNS isc on dc.definition=isc.column_default
				where isc.data_type='varchar'
				order by dc.name
			END
go

