CREATE PROCEDURE eis_idx_copy
			AS       
			BEGIN
				IF EXISTS  (SELECT * FROM sysobjects WHERE id = OBJECT_ID('TEMP_IDX_COPY_TABLE'))
				DROP TABLE TEMP_IDX_COPY_TABLE
				/*
				*	copy indexes to TEMP_IDX_COPY_TABLE
				*/
				SELECT 
					t.name as table_name, 
					isc.table_schema as table_schema, 
					i.Name AS index_name, 
					c.Name AS column_name, 
					ic.key_ordinal as column_order,
					i.is_unique as is_unique
				INTO TEMP_IDX_COPY_TABLE
				FROM sys.indexes i
				join sys.tables t on t.object_id=i.object_id
				JOIN sys.index_columns ic ON i.object_id = ic.object_id AND i.index_id = ic.index_id
				JOIN sys.columns c ON ic.object_id = c.object_id AND c.column_id = ic.column_id
				join INFORMATION_SCHEMA.TABLES isc on t.name=isc.table_name
				where t.type_desc='USER_TABLE'
				order by i.name
			END
go

