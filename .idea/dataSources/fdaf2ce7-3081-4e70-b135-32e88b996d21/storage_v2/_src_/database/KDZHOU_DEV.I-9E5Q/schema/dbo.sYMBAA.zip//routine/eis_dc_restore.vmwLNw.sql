CREATE PROCEDURE dbo.eis_dc_restore
			AS       
			BEGIN
				
				DECLARE @tsql nvarchar(max)
				/*
				*	Restore DC constraints
				*/
		
				DECLARE @restoreDCCount int
				SET @restoreDCCount = 0
				DECLARE
					@restoreConstraint$constraint_name nvarchar(128),
					@restoreConstraint$table_schema nvarchar(128),
					@restoreConstraint$table_name nvarchar(128),
					@restoreConstraint$definition nvarchar(128),
					@restoreConstraint$column_name nvarchar(128) 
							
				DECLARE restoreCursor CURSOR LOCAL FOR  
					SELECT name, table_schema, table_name, definition, column_name FROM TEMP_DC_COPY_TABLE
				OPEN restoreCursor 
				
				FETCH NEXT FROM restoreCursor 
					INTO @restoreConstraint$constraint_name, @restoreConstraint$table_schema, @restoreConstraint$table_name, @restoreConstraint$definition, @restoreConstraint$column_name
				WHILE @@FETCH_STATUS = 0
					BEGIN
						SET @tsql = 'ALTER TABLE [' + @restoreConstraint$table_schema + '].[' + @restoreConstraint$table_name + '] ADD CONSTRAINT ' + @restoreConstraint$constraint_name + ' DEFAULT ' + @restoreConstraint$definition + ' FOR ' + @restoreConstraint$column_name
						EXEC(@tsql)
						SET @restoreDCCount = @restoreDCCount + 1
						
						FETCH NEXT FROM restoreCursor
							INTO @restoreConstraint$constraint_name, @restoreConstraint$table_schema, @restoreConstraint$table_name, @restoreConstraint$definition, @restoreConstraint$column_name
					END
				CLOSE restoreCursor
				DEALLOCATE restoreCursor
				
				print 'DC restored: ' + cast(@restoreDCCount as varchar(10))
			END
go

